# Dataset

The data was collected by Nancy Howell. It can be found at this location.